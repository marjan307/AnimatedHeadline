$(document).ready(function () {
    $('.hero-text-box').animatedHeadline({
        animationType: 'clip'
    });
});